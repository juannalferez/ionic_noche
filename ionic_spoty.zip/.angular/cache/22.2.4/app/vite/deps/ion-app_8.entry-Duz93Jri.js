import { _ as readTask, a as config, c as createEvent, d as getElement, h as printIonWarning, l as forceUpdate, m as printIonError, p as h, r as Host, v as registerInstance, x as writeTask } from "./index-BpRUsN_W-Dyk8UFjA.js";
import { t as isRTL } from "./dir-Dj4J3LkD-B-ITPvLJ.js";
import { S as shallowEqualStringMap, a as componentOnReady, d as hasLazyBuild, i as clamp, p as inheritAriaAttributes } from "./helpers-p94IkmEA-5uAy2AkJ.js";
import { i as blockSwipeClicks, l as transition } from "./index-vgPixHgF-Gjvn9XbZ.js";
import { t as getTimeGivenProgression } from "./cubic-bezier-hHmYLOfE-CQJriwBy.js";
import "./gesture-controller-B_gJaBk0-B8pQAih_.js";
import { i as isPlatform, t as getIonMode } from "./ionic-global-Cep6oYzK-DYtGOxOW.js";
import { r as hostContext, t as createColorClasses } from "./theme-byZM6qHV-CVcL0HyM.js";
import { n as attachComponent, r as detachComponent } from "./framework-delegate-CW5_kWfc-BdHig9H3.js";
import { E as shouldUseCloseWatcher, m as getOverlaySizeType } from "./overlays-BBgMM61s-DkyFJ5KT.js";
import { a as findIonContent, c as getScrollElement, u as printIonContentErrorMsg } from "./index-CBkVO5D0-Bw1gCiS6.js";
import "./capacitor-BY7l8HgR-CUnDxgmh.js";
import "./keyboard-CutS8BPd-BiJqGMUj.js";
import { t as createLockController } from "./lock-controller-B-hirT0v-wdq_Ov9y.js";
import { t as createKeyboardController } from "./keyboard-controller-DqohyEsZ-2y3a41J2.js";
//#region node_modules/@ionic/core/dist/esm/ion-app_8.entry.js
/*!
* (C) Ionic http://ionicframework.com - MIT License
*/
var appCss = () => `html.plt-mobile ion-app{-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}html.plt-mobile ion-app [contenteditable]{-webkit-user-select:text;-moz-user-select:text;-ms-user-select:text;user-select:text}ion-app.force-statusbar-padding{--ion-safe-area-top:20px}`;
var App = class {
	constructor(hostRef) {
		registerInstance(this, hostRef);
	}
	componentDidLoad() {
		this.rIC(async () => {
			const isHybrid = isPlatform(window, "hybrid");
			if (!config.getBoolean("_testing")) import("./index-DLDbwWW7-Blbx_Hvh.js").then((module) => module.startTapClick(config));
			if (config.getBoolean("statusTap", isHybrid)) import("./status-tap-BskkGI4e-BDvaCTna.js").then((module) => module.startStatusTap());
			if (config.getBoolean("inputShims", needInputShims())) {
				/**
				* needInputShims() ensures that only iOS and Android
				* platforms proceed into this block.
				*/
				const platform = isPlatform(window, "ios") ? "ios" : "android";
				import("./input-shims-KNXj3DAv-C-U9PzNL.js").then((module) => module.startInputShims(config, platform));
			}
			const hardwareBackButtonModule = await import("./overlays-BBgMM61s-DkyFJ5KT.js").then((n) => n.y).then(function(n) {
				return n.y;
			});
			const supportsHardwareBackButtonEvents = isHybrid || shouldUseCloseWatcher();
			if (config.getBoolean("hardwareBackButton", supportsHardwareBackButtonEvents)) hardwareBackButtonModule.startHardwareBackButton();
			else {
				/**
				* If an app sets hardwareBackButton: false and experimentalCloseWatcher: true
				* then the close watcher will not be used.
				*/
				if (shouldUseCloseWatcher()) printIonWarning("[ion-app] - experimentalCloseWatcher was set to `true`, but hardwareBackButton was set to `false`. Both config options must be `true` for the Close Watcher API to be used.");
				hardwareBackButtonModule.blockHardwareBackButton();
			}
			if (typeof window !== "undefined") import("./keyboard-BumguZrM-Bc95mQgT.js").then((module) => module.startKeyboardAssist(window));
			import("./focus-visible-BmVRXR1y-BtHv7wfJ.js").then((module) => this.focusVisible = module.startFocusVisible());
		});
	}
	disconnectedCallback() {
		if (this.loadTimeout) clearTimeout(this.loadTimeout);
	}
	/**
	* Used to set focus on an element that uses `ion-focusable`.
	* Do not use this if focusing the element as a result of a keyboard
	* event as the focus utility should handle this for us. This method
	* should be used when we want to programmatically focus an element as
	* a result of another user action. (Ex: We focus the first element
	* inside of a popover when the user presents it, but the popover is not always
	* presented as a result of keyboard action.)
	*
	* @param elements An array of HTML elements to set focus on.
	*/
	async setFocus(elements) {
		if (this.focusVisible) this.focusVisible.setFocus(elements);
	}
	rIC(callback) {
		if ("requestIdleCallback" in window) window.requestIdleCallback(callback);
		else this.loadTimeout = setTimeout(callback, 32);
	}
	render() {
		const mode = getIonMode(this);
		return h(Host, {
			key: "77a7459d3e42b3715a5a7e1cf468e2ebc99e54bb",
			class: {
				[mode]: true,
				"ion-page": true,
				"force-statusbar-padding": config.getBoolean("_forceStatusbarPadding")
			}
		});
	}
	get el() {
		return getElement(this);
	}
};
var needInputShims = () => {
	if (isPlatform(window, "ios") && isPlatform(window, "mobile")) return true;
	if (isPlatform(window, "android") && isPlatform(window, "mobileweb")) return true;
	return false;
};
App.style = appCss();
var buttonsIosCss = () => `.sc-ion-buttons-ios-h{display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;-webkit-transform:translateZ(0);transform:translateZ(0);z-index:99}.sc-ion-buttons-ios-s ion-button{--padding-top:0;--padding-bottom:0;margin-left:0;margin-right:0;margin-top:0;margin-bottom:0}.sc-ion-buttons-ios-s ion-button{--padding-top:3px;--padding-bottom:3px;--padding-start:5px;--padding-end:5px;-webkit-margin-start:2px;margin-inline-start:2px;-webkit-margin-end:2px;margin-inline-end:2px;min-height:32px}.sc-ion-buttons-ios-s .button-has-icon-only{--padding-top:0;--padding-bottom:0}.sc-ion-buttons-ios-s ion-button:not(.button-round){--border-radius:4px}.sc-ion-buttons-ios-h.ion-color.sc-ion-buttons-ios-s .button,.ion-color .sc-ion-buttons-ios-h.sc-ion-buttons-ios-s .button{--color:initial;--border-color:initial;--background-focused:var(--ion-color-contrast)}.sc-ion-buttons-ios-h.ion-color.sc-ion-buttons-ios-s .button-solid,.ion-color .sc-ion-buttons-ios-h.sc-ion-buttons-ios-s .button-solid{--background:var(--ion-color-contrast);--background-focused:#000;--background-focused-opacity:.12;--background-activated:#000;--background-activated-opacity:.12;--background-hover:var(--ion-color-base);--background-hover-opacity:0.45;--color:var(--ion-color-base);--color-focused:var(--ion-color-base)}.sc-ion-buttons-ios-h.ion-color.sc-ion-buttons-ios-s .button-clear,.ion-color .sc-ion-buttons-ios-h.sc-ion-buttons-ios-s .button-clear{--color-activated:var(--ion-color-contrast);--color-focused:var(--ion-color-contrast)}.sc-ion-buttons-ios-h.ion-color.sc-ion-buttons-ios-s .button-outline,.ion-color .sc-ion-buttons-ios-h.sc-ion-buttons-ios-s .button-outline{--color-activated:var(--ion-color-base);--color-focused:var(--ion-color-contrast);--background-activated:var(--ion-color-contrast)}.sc-ion-buttons-ios-s .button-clear,.sc-ion-buttons-ios-s .button-outline{--background-activated:transparent;--background-focused:currentColor;--background-hover:transparent}.sc-ion-buttons-ios-s .button-solid:not(.ion-color){--background-focused:#000;--background-focused-opacity:.12;--background-activated:#000;--background-activated-opacity:.12}.sc-ion-buttons-ios-s ion-icon[slot=start]{margin-left:0;margin-right:0;margin-top:0;margin-bottom:0;-webkit-margin-end:0.3em;margin-inline-end:0.3em;font-size:1.41em;line-height:0.67}.sc-ion-buttons-ios-s ion-icon[slot=end]{margin-left:0;margin-right:0;margin-top:0;margin-bottom:0;-webkit-margin-start:0.4em;margin-inline-start:0.4em;font-size:1.41em;line-height:0.67}.sc-ion-buttons-ios-s ion-icon[slot=icon-only]{padding-left:0;padding-right:0;padding-top:0;padding-bottom:0;margin-left:0;margin-right:0;margin-top:0;margin-bottom:0;font-size:1.65em;line-height:0.67}`;
var buttonsMdCss = () => `.sc-ion-buttons-md-h{display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;-webkit-transform:translateZ(0);transform:translateZ(0);z-index:99}.sc-ion-buttons-md-s ion-button{--padding-top:0;--padding-bottom:0;margin-left:0;margin-right:0;margin-top:0;margin-bottom:0}.sc-ion-buttons-md-s ion-button{--padding-top:3px;--padding-bottom:3px;--padding-start:8px;--padding-end:8px;--box-shadow:none;-webkit-margin-start:2px;margin-inline-start:2px;-webkit-margin-end:2px;margin-inline-end:2px;min-height:32px}.sc-ion-buttons-md-s .button-has-icon-only{--padding-top:0;--padding-bottom:0}.sc-ion-buttons-md-s ion-button:not(.button-round){--border-radius:2px}.sc-ion-buttons-md-h.ion-color.sc-ion-buttons-md-s .button,.ion-color .sc-ion-buttons-md-h.sc-ion-buttons-md-s .button{--color:initial;--color-focused:var(--ion-color-contrast);--color-hover:var(--ion-color-contrast);--background-activated:transparent;--background-focused:var(--ion-color-contrast);--background-hover:var(--ion-color-contrast)}.sc-ion-buttons-md-h.ion-color.sc-ion-buttons-md-s .button-solid,.ion-color .sc-ion-buttons-md-h.sc-ion-buttons-md-s .button-solid{--background:var(--ion-color-contrast);--background-activated:transparent;--background-focused:var(--ion-color-shade);--background-hover:var(--ion-color-base);--color:var(--ion-color-base);--color-focused:var(--ion-color-base);--color-hover:var(--ion-color-base)}.sc-ion-buttons-md-h.ion-color.sc-ion-buttons-md-s .button-outline,.ion-color .sc-ion-buttons-md-h.sc-ion-buttons-md-s .button-outline{--border-color:var(--ion-color-contrast)}.sc-ion-buttons-md-s .button-has-icon-only.button-clear{--padding-top:12px;--padding-end:12px;--padding-bottom:12px;--padding-start:12px;--border-radius:50%;margin-left:0;margin-right:0;margin-top:0;margin-bottom:0;width:3rem;height:3rem}.sc-ion-buttons-md-s .button{--background-hover:currentColor}.sc-ion-buttons-md-s .button-solid{--color:var(--ion-toolbar-background, var(--ion-background-color, #fff));--background:var(--ion-toolbar-color, var(--ion-text-color, #424242));--background-activated:transparent;--background-focused:currentColor}.sc-ion-buttons-md-s .button-outline{--color:initial;--background:transparent;--background-activated:transparent;--background-focused:currentColor;--background-hover:currentColor;--border-color:currentColor}.sc-ion-buttons-md-s .button-clear{--color:initial;--background:transparent;--background-activated:transparent;--background-focused:currentColor;--background-hover:currentColor}.sc-ion-buttons-md-s ion-icon[slot=start]{margin-left:0;margin-right:0;margin-top:0;margin-bottom:0;-webkit-margin-end:0.3em;margin-inline-end:0.3em;font-size:1.4em}.sc-ion-buttons-md-s ion-icon[slot=end]{margin-left:0;margin-right:0;margin-top:0;margin-bottom:0;-webkit-margin-start:0.4em;margin-inline-start:0.4em;font-size:1.4em}.sc-ion-buttons-md-s ion-icon[slot=icon-only]{padding-left:0;padding-right:0;padding-top:0;padding-bottom:0;margin-left:0;margin-right:0;margin-top:0;margin-bottom:0;font-size:1.8em}`;
var Buttons = class {
	constructor(hostRef) {
		registerInstance(this, hostRef);
		/**
		* If true, buttons will disappear when its
		* parent toolbar has fully collapsed if the toolbar
		* is not the first toolbar. If the toolbar is the
		* first toolbar, the buttons will be hidden and will
		* only be shown once all toolbars have fully collapsed.
		*
		* Only applies in `ios` mode with `collapse` set to
		* `true` on `ion-header`.
		*
		* Typically used for [Collapsible Large Titles](https://ionicframework.com/docs/api/title#collapsible-large-titles)
		*/
		this.collapse = false;
	}
	render() {
		const mode = getIonMode(this);
		return h(Host, {
			key: "58c1fc5eb867d0731c63549b1ccb3ec3bbbe6e1b",
			class: {
				[mode]: true,
				["buttons-collapse"]: this.collapse
			}
		}, h("slot", { key: "0c8f95b9840c8fa0c4e50be84c5159620a3eb5c8" }));
	}
};
Buttons.style = {
	ios: buttonsIosCss(),
	md: buttonsMdCss()
};
var contentCss = () => `:host{--background:var(--ion-background-color, #fff);--color:var(--ion-text-color, #000);--padding-top:0px;--padding-bottom:0px;--padding-start:0px;--padding-end:0px;--keyboard-offset:0px;--offset-top:0px;--offset-bottom:0px;--overflow:auto;display:block;position:relative;-ms-flex:1;flex:1;width:100%;height:100%;margin:0 !important;padding:0 !important;font-family:var(--ion-font-family, inherit);contain:size style}:host(.ion-color) .inner-scroll{background:var(--ion-color-base);color:var(--ion-color-contrast)}#background-content{left:0px;right:0px;top:calc(var(--offset-top) * -1);bottom:calc(var(--offset-bottom) * -1);position:absolute;background:var(--background)}.inner-scroll{left:0px;right:0px;top:calc(var(--offset-top) * -1);bottom:calc(var(--offset-bottom) * -1);-webkit-padding-start:var(--padding-start);padding-inline-start:var(--padding-start);-webkit-padding-end:var(--padding-end);padding-inline-end:var(--padding-end);padding-top:calc(var(--padding-top) + var(--offset-top));padding-bottom:calc(var(--padding-bottom) + var(--keyboard-offset) + var(--offset-bottom) + var(--internal-content-safe-area-padding-bottom, 0px));position:absolute;color:var(--color);-webkit-box-sizing:border-box;box-sizing:border-box;overflow:hidden;-ms-touch-action:pan-x pan-y pinch-zoom;touch-action:pan-x pan-y pinch-zoom}.scroll-y,.scroll-x{-webkit-overflow-scrolling:touch;z-index:0;will-change:scroll-position}.scroll-y{overflow-y:var(--overflow);overscroll-behavior-y:contain}.scroll-x{overflow-x:var(--overflow);overscroll-behavior-x:contain}.overscroll::before,.overscroll::after{position:absolute;width:1px;height:1px;content:""}.overscroll::before{bottom:-1px}.overscroll::after{top:-1px}:host(.content-sizing){display:-ms-flexbox;display:flex;-ms-flex-direction:column;flex-direction:column;min-height:0;contain:none}:host(.content-sizing) .inner-scroll{position:relative;top:0;bottom:0;margin-top:calc(var(--offset-top) * -1);margin-bottom:calc(var(--offset-bottom) * -1)}.transition-effect{display:none;position:absolute;width:100%;height:100vh;opacity:0;pointer-events:none}:host(.content-ltr) .transition-effect{left:-100%;}:host(.content-rtl) .transition-effect{right:-100%;}.transition-cover{position:absolute;right:0;width:100%;height:100%;background:black;opacity:0.1}.transition-shadow{display:block;position:absolute;width:100%;height:100%;-webkit-box-shadow:inset -9px 0 9px 0 rgba(0, 0, 100, 0.03);box-shadow:inset -9px 0 9px 0 rgba(0, 0, 100, 0.03)}:host(.content-ltr) .transition-shadow{right:0;}:host(.content-rtl) .transition-shadow{left:0;-webkit-transform:scaleX(-1);transform:scaleX(-1)}::slotted([slot=fixed]){position:absolute;-webkit-transform:translateZ(0);transform:translateZ(0)}`;
var Content = class {
	constructor(hostRef) {
		registerInstance(this, hostRef);
		this.ionScrollStart = createEvent(this, "ionScrollStart", 7);
		this.ionScroll = createEvent(this, "ionScroll", 7);
		this.ionScrollEnd = createEvent(this, "ionScrollEnd", 7);
		this.watchDog = null;
		this.isScrolling = false;
		this.lastScroll = 0;
		this.queued = false;
		this.cTop = -1;
		this.cBottom = -1;
		this.isMainContent = true;
		this.resizeTimeout = null;
		this.inheritedAttributes = {};
		this.tabsElement = null;
		this.detail = {
			scrollTop: 0,
			scrollLeft: 0,
			type: "scroll",
			event: void 0,
			startX: 0,
			startY: 0,
			startTime: 0,
			currentX: 0,
			currentY: 0,
			velocityX: 0,
			velocityY: 0,
			deltaX: 0,
			deltaY: 0,
			currentTime: 0,
			data: void 0,
			isScrolling: true
		};
		/**
		* Whether the host is sized to its content.
		*/
		this.sizeToContent = false;
		/**
		* If `true`, the content will scroll behind the headers
		* and footers. This effect can easily be seen by setting the toolbar
		* to transparent.
		*/
		this.fullscreen = false;
		/**
		* Controls where the fixed content is placed relative to the main content
		* in the DOM. This can be used to control the order in which fixed elements
		* receive keyboard focus.
		* For example, if a FAB in the fixed slot should receive keyboard focus before
		* the main page content, set this property to `'before'`.
		*/
		this.fixedSlotPlacement = "after";
		/**
		* If you want to enable the content scrolling in the X axis, set this property to `true`.
		*/
		this.scrollX = false;
		/**
		* If you want to disable the content scrolling in the Y axis, set this property to `false`.
		*/
		this.scrollY = true;
		/**
		* Because of performance reasons, ionScroll events are disabled by default, in order to enable them
		* and start listening from (ionScroll), set this property to `true`.
		*/
		this.scrollEvents = false;
	}
	fullscreenChanged() {
		this.setupFullscreenResizeObserver();
	}
	componentWillLoad() {
		this.inheritedAttributes = inheritAriaAttributes(this.el);
		this.sizeToContent = this.readSizeToContent();
	}
	connectedCallback() {
		this.isMainContent = this.el.closest("ion-menu, ion-popover, ion-modal") === null;
		/**
		* The fullscreen content offsets need to be
		* computed after the tab bar has loaded. Since
		* lazy evaluation means components are not hydrated
		* at the same time, we need to wait for the ionTabBarLoaded
		* event to fire. This does not impact dist-custom-elements
		* because there is no hydration there.
		*/
		if (hasLazyBuild(this.el)) {
			/**
			* We need to cache the reference to the tabs.
			* If just the content is unmounted then we won't
			* be able to query for the closest tabs on disconnectedCallback
			* since the content has been removed from the DOM tree.
			*/
			const closestTabs = this.tabsElement = this.el.closest("ion-tabs");
			if (closestTabs !== null) {
				/**
				* When adding and removing the event listener
				* we need to make sure we pass the same function reference
				* otherwise the event listener will not be removed properly.
				* We can't only pass `this.resize` because "this" in the function
				* context becomes a reference to IonTabs instead of IonContent.
				*
				* Additionally, we listen for ionTabBarLoaded on the IonTabs
				* instance rather than the IonTabBar instance. It's possible for
				* a tab bar to be conditionally rendered/mounted. Since ionTabBarLoaded
				* bubbles, we can catch any instances of child tab bars loading by listening
				* on IonTabs.
				*/
				this.tabsLoadCallback = () => this.resize();
				closestTabs.addEventListener("ionTabBarLoaded", this.tabsLoadCallback);
			}
		}
		this.setupFullscreenResizeObserver();
		this.updateSizeToContent();
	}
	componentDidLoad() {
		this.setupFullscreenResizeObserver();
	}
	disconnectedCallback() {
		this.onScrollEnd();
		if (hasLazyBuild(this.el)) {
			/**
			* The event listener and tabs caches need to
			* be cleared otherwise this will create a memory
			* leak where the IonTabs instance can never be
			* garbage collected.
			*/
			const { tabsElement, tabsLoadCallback } = this;
			if (tabsElement !== null && tabsLoadCallback !== void 0) tabsElement.removeEventListener("ionTabBarLoaded", tabsLoadCallback);
			this.tabsElement = null;
			this.tabsLoadCallback = void 0;
		}
		if (this.resizeTimeout) {
			clearTimeout(this.resizeTimeout);
			this.resizeTimeout = null;
		}
		this.destroyFullscreenResizeObserver();
	}
	/**
	* Header and footer sizes can change after load without a window resize
	* firing, so the `resize` listener alone misses those changes.
	*
	* Popover content is excluded because `contain: none` lets its offsets drive
	* the host's own height, which would feed back into the observer.
	*/
	setupFullscreenResizeObserver() {
		if (typeof ResizeObserver === "undefined") return;
		if (!this.fullscreen || hostContext("ion-popover", this.el)) {
			this.destroyFullscreenResizeObserver();
			return;
		}
		if (this.fullscreenResizeObserver !== void 0) return;
		this.fullscreenResizeObserver = new ResizeObserver(() => {
			if (this.el.offsetParent === null) return;
			this.resize();
		});
		this.fullscreenResizeObserver.observe(this.el);
	}
	/**
	* Picks up an overlay that is no longer sized the way the last render
	* assumed, re-rendering only when the answer changes. Read in a `readTask`
	* because resolving the custom property forces a style recalculation.
	*/
	updateSizeToContent() {
		readTask(() => {
			this.sizeToContent = this.readSizeToContent();
		});
	}
	destroyFullscreenResizeObserver() {
		if (this.fullscreenResizeObserver !== void 0) {
			this.fullscreenResizeObserver.disconnect();
			this.fullscreenResizeObserver = void 0;
		}
	}
	/**
	* Rotating certain devices can update
	* the safe area insets. As a result,
	* the fullscreen feature on ion-content
	* needs to be recalculated.
	*
	* We listen for "resize" because we
	* do not care what the orientation of
	* the device is. Other APIs
	* such as ScreenOrientation or
	* the deviceorientation event must have
	* permission from the user first whereas
	* the "resize" event does not.
	*
	* We also throttle the callback to minimize
	* thrashing when quickly resizing a window.
	*/
	onResize() {
		if (this.resizeTimeout) {
			clearTimeout(this.resizeTimeout);
			this.resizeTimeout = null;
		}
		this.resizeTimeout = setTimeout(() => {
			/**
			* Resize should only happen
			* if the content is visible.
			* When the content is hidden
			* then offsetParent will be null.
			*/
			if (this.el.offsetParent === null) return;
			this.resize();
		}, 100);
	}
	shouldForceOverscroll() {
		const { forceOverscroll } = this;
		const mode = getIonMode(this);
		return forceOverscroll === void 0 ? mode === "ios" && isPlatform("ios") : forceOverscroll;
	}
	/**
	* Reads whether to size the component to its content height. Forces a style
	* recalculation, so it belongs in a read task or before the first render.
	*
	* This applies inside popovers and modals with a content-based `--height`,
	* where the overlay does not provide the content with a definite height
	* to fill.
	*
	* Only `--height` is consulted. Styling the wrapper directly, such as
	* `ion-modal::part(content) { height: fit-content; }`, does not change
	* `--height` and therefore cannot be observed. `--height` is the only
	* supported way to opt into content-based sizing.
	*/
	readSizeToContent() {
		if (hostContext("ion-popover", this.el)) return true;
		const modal = this.el.closest("ion-modal");
		if (modal === null) return false;
		const height = getComputedStyle(modal).getPropertyValue("--height");
		return getOverlaySizeType(height) === "content";
	}
	resize() {
		/**
		* A window resize can cross a media query that changes the modal's
		* `--height`. The content's own offsets are unchanged, so neither branch
		* below re-renders and the class from the last render would go stale.
		*/
		this.updateSizeToContent();
		if (this.fullscreen) readTask(() => this.readDimensions());
		else if (this.cTop !== 0 || this.cBottom !== 0) {
			this.cTop = this.cBottom = 0;
			forceUpdate(this);
		}
	}
	/**
	* Recalculates the content dimensions and whether it should size itself to
	* its content. Called by overlays when something they own changes, such as
	* a header finishing its render or `--height` being updated.
	*
	* @internal
	*/
	async recalculateDimensions() {
		readTask(() => this.readDimensions());
		this.updateSizeToContent();
	}
	readDimensions() {
		const page = getPageElement(this.el);
		const top = Math.max(this.el.offsetTop, 0);
		const bottom = Math.max(page.offsetHeight - top - this.el.offsetHeight, 0);
		if (top !== this.cTop || bottom !== this.cBottom) {
			this.cTop = top;
			this.cBottom = bottom;
			forceUpdate(this);
		}
	}
	onScroll(ev) {
		const timeStamp = Date.now();
		const shouldStart = !this.isScrolling;
		this.lastScroll = timeStamp;
		if (shouldStart) this.onScrollStart();
		if (!this.queued && this.scrollEvents) {
			this.queued = true;
			readTask((ts) => {
				this.queued = false;
				this.detail.event = ev;
				updateScrollDetail(this.detail, this.scrollEl, ts, shouldStart);
				this.ionScroll.emit(this.detail);
			});
		}
	}
	/**
	* Get the element where the actual scrolling takes place.
	* This element can be used to subscribe to `scroll` events or manually modify
	* `scrollTop`. However, it's recommended to use the API provided by `ion-content`:
	*
	* i.e. Using `ionScroll`, `ionScrollStart`, `ionScrollEnd` for scrolling events
	* and `scrollToPoint()` to scroll the content into a certain point.
	*/
	async getScrollElement() {
		/**
		* If this gets called in certain early lifecycle hooks (ex: Vue onMounted),
		* scrollEl won't be defined yet with the custom elements build, so wait for it to load in.
		*/
		if (!this.scrollEl) await new Promise((resolve) => componentOnReady(this.el, resolve));
		return Promise.resolve(this.scrollEl);
	}
	/**
	* Returns the background content element.
	* @internal
	*/
	async getBackgroundElement() {
		if (!this.backgroundContentEl) await new Promise((resolve) => componentOnReady(this.el, resolve));
		return Promise.resolve(this.backgroundContentEl);
	}
	/**
	* Scroll to the top of the component.
	*
	* @param duration The amount of time to take scrolling to the top. Defaults to `0`.
	*/
	scrollToTop(duration = 0) {
		return this.scrollToPoint(void 0, 0, duration);
	}
	/**
	* Scroll to the bottom of the component.
	*
	* @param duration The amount of time to take scrolling to the bottom. Defaults to `0`.
	*/
	async scrollToBottom(duration = 0) {
		const scrollEl = await this.getScrollElement();
		const y = scrollEl.scrollHeight - scrollEl.clientHeight;
		return this.scrollToPoint(void 0, y, duration);
	}
	/**
	* Scroll by a specified X/Y distance in the component.
	*
	* @param x The amount to scroll by on the horizontal axis.
	* @param y The amount to scroll by on the vertical axis.
	* @param duration The amount of time to take scrolling by that amount.
	*/
	async scrollByPoint(x, y, duration) {
		const scrollEl = await this.getScrollElement();
		return this.scrollToPoint(x + scrollEl.scrollLeft, y + scrollEl.scrollTop, duration);
	}
	/**
	* Scroll to a specified X/Y location in the component.
	*
	* @param x The point to scroll to on the horizontal axis.
	* @param y The point to scroll to on the vertical axis.
	* @param duration The amount of time to take scrolling to that point. Defaults to `0`.
	*/
	async scrollToPoint(x, y, duration = 0) {
		const el = await this.getScrollElement();
		if (duration < 32) {
			if (y != null) el.scrollTop = y;
			if (x != null) el.scrollLeft = x;
			return;
		}
		let resolve;
		let startTime = 0;
		const promise = new Promise((r) => resolve = r);
		const fromY = el.scrollTop;
		const fromX = el.scrollLeft;
		const deltaY = y != null ? y - fromY : 0;
		const deltaX = x != null ? x - fromX : 0;
		const step = (timeStamp) => {
			const linearTime = Math.min(1, (timeStamp - startTime) / duration) - 1;
			const easedT = Math.pow(linearTime, 3) + 1;
			if (deltaY !== 0) el.scrollTop = Math.floor(easedT * deltaY + fromY);
			if (deltaX !== 0) el.scrollLeft = Math.floor(easedT * deltaX + fromX);
			if (easedT < 1) requestAnimationFrame(step);
			else resolve();
		};
		requestAnimationFrame((ts) => {
			startTime = ts;
			step(ts);
		});
		return promise;
	}
	onScrollStart() {
		this.isScrolling = true;
		this.ionScrollStart.emit({ isScrolling: true });
		if (this.watchDog) clearInterval(this.watchDog);
		this.watchDog = setInterval(() => {
			if (this.lastScroll < Date.now() - 120) this.onScrollEnd();
		}, 100);
	}
	onScrollEnd() {
		if (this.watchDog) clearInterval(this.watchDog);
		this.watchDog = null;
		if (this.isScrolling) {
			this.isScrolling = false;
			this.ionScrollEnd.emit({ isScrolling: false });
		}
	}
	render() {
		const { fixedSlotPlacement, inheritedAttributes, isMainContent, scrollX, scrollY, el } = this;
		const rtl = isRTL(el) ? "rtl" : "ltr";
		const mode = getIonMode(this);
		const forceOverscroll = this.shouldForceOverscroll();
		const transitionShadow = mode === "ios";
		this.resize();
		return h(Host, {
			key: "e1013621096729354ef92915af52dd823e69fdff",
			role: isMainContent ? "main" : void 0,
			class: createColorClasses(this.color, {
				[mode]: true,
				"content-fullscreen": this.fullscreen,
				"content-sizing": this.sizeToContent,
				overscroll: forceOverscroll,
				[`content-${rtl}`]: true
			}),
			style: {
				"--offset-top": `${this.cTop}px`,
				"--offset-bottom": `${this.cBottom}px`
			},
			...inheritedAttributes
		}, h("div", {
			key: "3d8649b164d6324beaa1bc50e1d204ad06c2ec1a",
			ref: (el) => this.backgroundContentEl = el,
			id: "background-content",
			part: "background"
		}), fixedSlotPlacement === "before" ? h("slot", { name: "fixed" }) : null, h("div", {
			key: "dd2d3bed8690b4f5027a43f5ec60e7e7df18106d",
			class: {
				"inner-scroll": true,
				"scroll-x": scrollX,
				"scroll-y": scrollY,
				overscroll: (scrollX || scrollY) && forceOverscroll
			},
			ref: (scrollEl) => this.scrollEl = scrollEl,
			onScroll: this.scrollEvents ? (ev) => this.onScroll(ev) : void 0,
			part: "scroll"
		}, h("slot", { key: "dc3d4584d9e9afd43699525a619b8e873078fbbf" })), transitionShadow ? h("div", { class: "transition-effect" }, h("div", { class: "transition-cover" }), h("div", { class: "transition-shadow" })) : null, fixedSlotPlacement === "after" ? h("slot", { name: "fixed" }) : null);
	}
	get el() {
		return getElement(this);
	}
	static get watchers() {
		return { "fullscreen": [{ "fullscreenChanged": 0 }] };
	}
};
var getParentElement = (el) => {
	if (el.parentElement) return el.parentElement;
	if (el.parentNode?.host) return el.parentNode.host;
	return null;
};
var getPageElement = (el) => {
	const tabs = el.closest("ion-tabs");
	if (tabs) return tabs;
	/**
	* If we're in a popover, we need to use its wrapper so we can account for space
	* between the popover and the edges of the screen. But if the popover contains
	* its own page element, we should use that instead.
	*/
	const page = el.closest("ion-app, ion-page, .ion-page, page-inner, .popover-content");
	if (page) return page;
	return getParentElement(el);
};
var updateScrollDetail = (detail, el, timestamp, shouldStart) => {
	const prevX = detail.currentX;
	const prevY = detail.currentY;
	const prevT = detail.currentTime;
	const currentX = el.scrollLeft;
	const currentY = el.scrollTop;
	const timeDelta = timestamp - prevT;
	if (shouldStart) {
		detail.startTime = timestamp;
		detail.startX = currentX;
		detail.startY = currentY;
		detail.velocityX = detail.velocityY = 0;
	}
	detail.currentTime = timestamp;
	detail.currentX = detail.scrollLeft = currentX;
	detail.currentY = detail.scrollTop = currentY;
	detail.deltaX = currentX - detail.startX;
	detail.deltaY = currentY - detail.startY;
	if (timeDelta > 0 && timeDelta < 100) {
		const velocityX = (currentX - prevX) / timeDelta;
		const velocityY = (currentY - prevY) / timeDelta;
		detail.velocityX = velocityX * .7 + detail.velocityX * .3;
		detail.velocityY = velocityY * .7 + detail.velocityY * .3;
	}
};
Content.style = contentCss();
var handleFooterFade = (scrollEl, baseEl) => {
	readTask(() => {
		const scrollTop = scrollEl.scrollTop;
		const maxScroll = scrollEl.scrollHeight - scrollEl.clientHeight;
		/**
		* Toolbar background will fade
		* out over fadeDuration in pixels.
		*/
		const fadeDuration = 10;
		const distanceToStart = scrollTop - (maxScroll - fadeDuration);
		const scale = clamp(0, 1 - distanceToStart / fadeDuration, 1);
		writeTask(() => {
			baseEl.style.setProperty("--opacity-scale", scale.toString());
		});
	});
};
var footerIosCss = () => `ion-footer{display:block;position:relative;-ms-flex-order:1;order:1;width:100%;z-index:10}ion-footer.footer-toolbar-padding ion-toolbar:last-of-type{padding-bottom:var(--ion-safe-area-bottom, 0)}.footer-ios ion-toolbar:first-of-type{--border-width:0.55px 0 0}@supports ((-webkit-backdrop-filter: blur(0)) or (backdrop-filter: blur(0))){.footer-background{left:0;right:0;top:0;bottom:0;position:absolute;-webkit-backdrop-filter:saturate(180%) blur(20px);backdrop-filter:saturate(180%) blur(20px)}.footer-translucent-ios ion-toolbar{--opacity:.8}}.footer-ios.ion-no-border ion-toolbar:first-of-type{--border-width:0}.footer-collapse-fade ion-toolbar{--opacity-scale:inherit}`;
var footerMdCss = () => `ion-footer{display:block;position:relative;-ms-flex-order:1;order:1;width:100%;z-index:10}ion-footer.footer-toolbar-padding ion-toolbar:last-of-type{padding-bottom:var(--ion-safe-area-bottom, 0)}.footer-md{-webkit-box-shadow:0 2px 4px -1px rgba(0, 0, 0, 0.2), 0 4px 5px 0 rgba(0, 0, 0, 0.14), 0 1px 10px 0 rgba(0, 0, 0, 0.12);box-shadow:0 2px 4px -1px rgba(0, 0, 0, 0.2), 0 4px 5px 0 rgba(0, 0, 0, 0.14), 0 1px 10px 0 rgba(0, 0, 0, 0.12)}.footer-md.ion-no-border{-webkit-box-shadow:none;box-shadow:none}`;
var Footer = class {
	constructor(hostRef) {
		registerInstance(this, hostRef);
		this.keyboardCtrl = null;
		this.keyboardCtrlPromise = null;
		this.keyboardVisible = false;
		/**
		* If `true`, the footer will be translucent.
		* Only applies when the mode is `"ios"` and the device supports
		* [`backdrop-filter`](https://developer.mozilla.org/en-US/docs/Web/CSS/backdrop-filter#Browser_compatibility).
		*
		* Note: In order to scroll content behind the footer, the `fullscreen`
		* attribute needs to be set on the content.
		*/
		this.translucent = false;
		this.checkCollapsibleFooter = () => {
			if (getIonMode(this) !== "ios") return;
			const { collapse } = this;
			const hasFade = collapse === "fade";
			this.destroyCollapsibleFooter();
			if (hasFade) {
				const pageEl = this.el.closest("ion-app,ion-page,.ion-page,page-inner");
				const contentEl = pageEl ? findIonContent(pageEl) : null;
				if (!contentEl) {
					printIonContentErrorMsg(this.el);
					return;
				}
				this.setupFadeFooter(contentEl);
			}
		};
		this.setupFadeFooter = async (contentEl) => {
			const scrollEl = this.scrollEl = await getScrollElement(contentEl);
			/**
			* Handle fading of toolbars on scroll
			*/
			this.contentScrollCallback = () => {
				handleFooterFade(scrollEl, this.el);
			};
			scrollEl.addEventListener("scroll", this.contentScrollCallback);
			handleFooterFade(scrollEl, this.el);
		};
	}
	componentDidLoad() {
		this.checkCollapsibleFooter();
	}
	componentDidUpdate() {
		this.checkCollapsibleFooter();
	}
	async connectedCallback() {
		const promise = createKeyboardController(async (keyboardOpen, waitForResize) => {
			/**
			* If the keyboard is hiding, then we need to wait
			* for the webview to resize. Otherwise, the footer
			* will flicker before the webview resizes.
			*/
			if (keyboardOpen === false && waitForResize !== void 0) await waitForResize;
			this.keyboardVisible = keyboardOpen;
		});
		this.keyboardCtrlPromise = promise;
		const keyboardCtrl = await promise;
		/**
		* Only assign if this is still the current promise.
		* Otherwise, a new connectedCallback has started or
		* disconnectedCallback was called, so destroy this instance.
		*/
		if (this.keyboardCtrlPromise === promise) {
			this.keyboardCtrl = keyboardCtrl;
			this.keyboardCtrlPromise = null;
		} else keyboardCtrl.destroy();
	}
	disconnectedCallback() {
		if (this.keyboardCtrlPromise) {
			this.keyboardCtrlPromise.then((ctrl) => ctrl.destroy());
			this.keyboardCtrlPromise = null;
		}
		if (this.keyboardCtrl) {
			this.keyboardCtrl.destroy();
			this.keyboardCtrl = null;
		}
	}
	destroyCollapsibleFooter() {
		if (this.scrollEl && this.contentScrollCallback) {
			this.scrollEl.removeEventListener("scroll", this.contentScrollCallback);
			this.contentScrollCallback = void 0;
		}
	}
	render() {
		const { translucent, collapse } = this;
		const mode = getIonMode(this);
		const tabBar = this.el.closest("ion-tabs")?.querySelector(":scope > ion-tab-bar");
		return h(Host, {
			key: "71939c4bbaef5062532a99ee2e33574102a9abad",
			role: "contentinfo",
			class: {
				[mode]: true,
				[`footer-${mode}`]: true,
				[`footer-translucent`]: translucent,
				[`footer-translucent-${mode}`]: translucent,
				["footer-toolbar-padding"]: !this.keyboardVisible && (!tabBar || tabBar.slot !== "bottom"),
				[`footer-collapse-${collapse}`]: collapse !== void 0
			}
		}, mode === "ios" && translucent && h("div", {
			key: "2fa14f61661c47c661cecd696176728d6eafa74f",
			class: "footer-background"
		}), h("slot", { key: "8e63696e7c528d5c38201e546bf08135290d0945" }));
	}
	get el() {
		return getElement(this);
	}
};
Footer.style = {
	ios: footerIosCss(),
	md: footerMdCss()
};
var TRANSITION = "all 0.2s ease-in-out";
var ROLE_NONE = "none";
var ROLE_BANNER = "banner";
var cloneElement = (tagName) => {
	const getCachedEl = document.querySelector(`${tagName}.ion-cloned-element`);
	if (getCachedEl !== null) return getCachedEl;
	const clonedEl = document.createElement(tagName);
	clonedEl.classList.add("ion-cloned-element");
	clonedEl.style.setProperty("display", "none");
	document.body.appendChild(clonedEl);
	return clonedEl;
};
var createHeaderIndex = (headerEl) => {
	if (!headerEl) return;
	const toolbars = headerEl.querySelectorAll("ion-toolbar");
	return {
		el: headerEl,
		toolbars: Array.from(toolbars).map((toolbar) => {
			const ionTitleEl = toolbar.querySelector("ion-title");
			return {
				el: toolbar,
				background: toolbar.shadowRoot.querySelector(".toolbar-background"),
				ionTitleEl,
				innerTitleEl: ionTitleEl ? ionTitleEl.shadowRoot.querySelector(".toolbar-title") : null,
				ionButtonsEl: Array.from(toolbar.querySelectorAll("ion-buttons"))
			};
		})
	};
};
var handleContentScroll = (scrollEl, scrollHeaderIndex, contentEl) => {
	readTask(() => {
		const scrollTop = scrollEl.scrollTop;
		const scale = clamp(1, 1 + -scrollTop / 500, 1.1);
		if (contentEl.querySelector("ion-refresher.refresher-native") === null) writeTask(() => {
			scaleLargeTitles(scrollHeaderIndex.toolbars, scale);
		});
	});
};
var setToolbarBackgroundOpacity = (headerEl, opacity) => {
	/**
	* Fading in the backdrop opacity
	* should happen after the large title
	* has collapsed, so it is handled
	* by handleHeaderFade()
	*/
	if (headerEl.collapse === "fade") return;
	if (opacity === void 0) headerEl.style.removeProperty("--opacity-scale");
	else headerEl.style.setProperty("--opacity-scale", opacity.toString());
};
var handleToolbarBorderIntersection = (ev, mainHeaderIndex, scrollTop) => {
	if (!ev[0].isIntersecting) return;
	/**
	* There is a bug in Safari where overflow scrolling on a non-body element
	* does not always reset the scrollTop position to 0 when letting go. It will
	* set to 1 once the rubber band effect has ended. This causes the background to
	* appear slightly on certain app setups.
	*
	* Additionally, we check if user is rubber banding (scrolling is negative)
	* as this can mean they are using pull to refresh. Once the refresher starts,
	* the content is transformed which can cause the intersection observer to erroneously
	* fire here as well.
	*/
	const scale = ev[0].intersectionRatio > .9 || scrollTop <= 0 ? 0 : (1 - ev[0].intersectionRatio) * 100 / 75;
	setToolbarBackgroundOpacity(mainHeaderIndex.el, scale === 1 ? void 0 : scale);
};
/**
* If toolbars are intersecting, hide the scrollable toolbar content
* and show the primary toolbar content. If the toolbars are not intersecting,
* hide the primary toolbar content and show the scrollable toolbar content
*/
var handleToolbarIntersection = (ev, mainHeaderIndex, scrollHeaderIndex, scrollEl) => {
	writeTask(() => {
		const scrollTop = scrollEl.scrollTop;
		handleToolbarBorderIntersection(ev, mainHeaderIndex, scrollTop);
		const event = ev[0];
		const intersection = event.intersectionRect;
		const intersectionArea = intersection.width * intersection.height;
		const rootArea = event.rootBounds.width * event.rootBounds.height;
		const isPageHidden = intersectionArea === 0 && rootArea === 0;
		const leftDiff = Math.abs(intersection.left - event.boundingClientRect.left);
		const rightDiff = Math.abs(intersection.right - event.boundingClientRect.right);
		if (isPageHidden || intersectionArea > 0 && (leftDiff >= 5 || rightDiff >= 5)) return;
		if (event.isIntersecting) {
			setHeaderActive(mainHeaderIndex, false);
			setHeaderActive(scrollHeaderIndex);
		} else if ((intersection.x === 0 && intersection.y === 0 || intersection.width !== 0 && intersection.height !== 0) && scrollTop > 0) {
			setHeaderActive(mainHeaderIndex);
			setHeaderActive(scrollHeaderIndex, false);
			setToolbarBackgroundOpacity(mainHeaderIndex.el);
		}
	});
};
var setHeaderActive = (headerIndex, active = true) => {
	const headerEl = headerIndex.el;
	const ionTitles = headerIndex.toolbars.map((toolbar) => toolbar.ionTitleEl);
	if (active) {
		headerEl.setAttribute("role", ROLE_BANNER);
		headerEl.classList.remove("header-collapse-condense-inactive");
		ionTitles.forEach((ionTitle) => {
			if (ionTitle) ionTitle.removeAttribute("aria-hidden");
		});
	} else {
		/**
		* There can only be one banner landmark per page.
		* By default, all ion-headers have the banner role.
		* This causes an accessibility issue when using a
		* condensed header since there are two ion-headers
		* on the page at once (active and inactive).
		* To solve this, the role needs to be toggled
		* based on which header is active.
		*/
		headerEl.setAttribute("role", ROLE_NONE);
		headerEl.classList.add("header-collapse-condense-inactive");
		/**
		* The small title should only be accessed by screen readers
		* when the large title collapses into the small title due
		* to scrolling.
		*
		* Originally, the header was given `aria-hidden="true"`
		* but this caused issues with screen readers not being
		* able to access any focusable elements within the header.
		*/
		ionTitles.forEach((ionTitle) => {
			if (ionTitle) ionTitle.setAttribute("aria-hidden", "true");
		});
	}
};
var scaleLargeTitles = (toolbars = [], scale = 1, transition = false) => {
	toolbars.forEach((toolbar) => {
		const ionTitle = toolbar.ionTitleEl;
		const titleDiv = toolbar.innerTitleEl;
		if (!ionTitle || ionTitle.size !== "large") return;
		titleDiv.style.transition = transition ? TRANSITION : "";
		titleDiv.style.transform = `scale3d(${scale}, ${scale}, 1)`;
	});
};
var handleHeaderFade = (scrollEl, baseEl, condenseHeader) => {
	readTask(() => {
		const scrollTop = scrollEl.scrollTop;
		const baseElHeight = baseEl.clientHeight;
		const fadeStart = condenseHeader ? condenseHeader.clientHeight : 0;
		/**
		* If we are using fade header with a condense
		* header, then the toolbar backgrounds should
		* not begin to fade in until the condense
		* header has fully collapsed.
		*
		* Additionally, the main content should not
		* overflow out of the container until the
		* condense header has fully collapsed. When
		* using just the condense header the content
		* should overflow out of the container.
		*/
		if (condenseHeader !== null && scrollTop < fadeStart) {
			baseEl.style.setProperty("--opacity-scale", "0");
			scrollEl.style.setProperty("clip-path", `inset(${baseElHeight}px 0px 0px 0px)`);
			return;
		}
		const distanceToStart = scrollTop - fadeStart;
		const scale = clamp(0, distanceToStart / 10, 1);
		writeTask(() => {
			scrollEl.style.removeProperty("clip-path");
			baseEl.style.setProperty("--opacity-scale", scale.toString());
		});
	});
};
/**
* Get the role type for the ion-header.
*
* @param isInsideMenu If ion-header is inside ion-menu.
* @param isCondensed If ion-header has collapse="condense".
* @param mode The current mode.
* @returns 'none' if inside ion-menu or if condensed in md
* mode, otherwise 'banner'.
*/
var getRoleType = (isInsideMenu, isCondensed, mode) => {
	if (isInsideMenu) return ROLE_NONE;
	/**
	* Only apply role="none" to `md` mode condensed headers
	* since the large header is never shown.
	*/
	if (isCondensed && mode === "md") return ROLE_NONE;
	return ROLE_BANNER;
};
var headerIosCss = () => `ion-header{display:block;position:relative;-ms-flex-order:-1;order:-1;width:100%;z-index:10}ion-header ion-toolbar:first-of-type{padding-top:var(--ion-safe-area-top, 0)}.header-ios ion-toolbar:last-of-type{--border-width:0 0 0.55px}@supports ((-webkit-backdrop-filter: blur(0)) or (backdrop-filter: blur(0))){.header-background{left:0;right:0;top:0;bottom:0;position:absolute;-webkit-backdrop-filter:saturate(180%) blur(20px);backdrop-filter:saturate(180%) blur(20px)}.header-translucent-ios ion-toolbar{--opacity:.8}.header-collapse-condense-inactive .header-background{-webkit-backdrop-filter:blur(20px);backdrop-filter:blur(20px)}}.header-ios.ion-no-border ion-toolbar:last-of-type{--border-width:0}.header-collapse-fade ion-toolbar{--opacity-scale:inherit}.header-collapse-fade.header-transitioning ion-toolbar{--background:transparent;--border-style:none}.header-collapse-condense{z-index:9}.header-collapse-condense ion-toolbar{position:-webkit-sticky;position:sticky;top:0}.header-collapse-condense ion-toolbar:first-of-type{padding-top:0px;z-index:1}.header-collapse-condense ion-toolbar{z-index:0}.header-collapse-condense ion-toolbar:last-of-type{--border-width:0px}.header-collapse-condense ion-toolbar ion-searchbar{padding-top:0px;padding-bottom:13px}.header-collapse-main{--opacity-scale:1}.header-collapse-main ion-toolbar{--opacity-scale:inherit}.header-collapse-main ion-toolbar.in-toolbar ion-title,.header-collapse-main ion-toolbar.in-toolbar ion-buttons{-webkit-transition:all 0.2s ease-in-out;transition:all 0.2s ease-in-out}.header-collapse-condense ion-toolbar,.header-collapse-condense-inactive.header-transitioning:not(.header-collapse-condense) ion-toolbar{--background:var(--ion-background-color, #fff)}.header-collapse-condense-inactive.header-transitioning:not(.header-collapse-condense) ion-toolbar{--border-style:none;--opacity-scale:1}.header-collapse-condense-inactive:not(.header-collapse-condense) ion-toolbar.in-toolbar ion-title,.header-collapse-condense-inactive:not(.header-collapse-condense) ion-toolbar.in-toolbar ion-buttons.buttons-collapse{opacity:0;pointer-events:none}.header-collapse-condense-inactive.header-collapse-condense ion-toolbar.in-toolbar ion-title,.header-collapse-condense-inactive.header-collapse-condense ion-toolbar.in-toolbar ion-buttons.buttons-collapse{visibility:hidden}ion-header.header-ios:not(.header-collapse-main):has(~ion-content ion-header.header-ios[collapse=condense],~ion-content ion-header.header-ios.header-collapse-condense){opacity:0}`;
var headerMdCss = () => `ion-header{display:block;position:relative;-ms-flex-order:-1;order:-1;width:100%;z-index:10}ion-header ion-toolbar:first-of-type{padding-top:var(--ion-safe-area-top, 0)}.header-md{-webkit-box-shadow:0 2px 4px -1px rgba(0, 0, 0, 0.2), 0 4px 5px 0 rgba(0, 0, 0, 0.14), 0 1px 10px 0 rgba(0, 0, 0, 0.12);box-shadow:0 2px 4px -1px rgba(0, 0, 0, 0.2), 0 4px 5px 0 rgba(0, 0, 0, 0.14), 0 1px 10px 0 rgba(0, 0, 0, 0.12)}.header-md.header-collapse-condense{display:none}.header-md.ion-no-border{-webkit-box-shadow:none;box-shadow:none}`;
var Header = class {
	constructor(hostRef) {
		registerInstance(this, hostRef);
		this.inheritedAttributes = {};
		/**
		* If `true`, the header will be translucent.
		* Only applies when the mode is `"ios"` and the device supports
		* [`backdrop-filter`](https://developer.mozilla.org/en-US/docs/Web/CSS/backdrop-filter#Browser_compatibility).
		*
		* Note: In order to scroll content behind the header, the `fullscreen`
		* attribute needs to be set on the content.
		*/
		this.translucent = false;
		this.setupFadeHeader = async (contentEl, condenseHeader) => {
			const scrollEl = this.scrollEl = await getScrollElement(contentEl);
			/**
			* Handle fading of toolbars on scroll
			*/
			this.contentScrollCallback = () => {
				handleHeaderFade(this.scrollEl, this.el, condenseHeader);
			};
			scrollEl.addEventListener("scroll", this.contentScrollCallback);
			handleHeaderFade(this.scrollEl, this.el, condenseHeader);
		};
	}
	componentWillLoad() {
		this.inheritedAttributes = inheritAriaAttributes(this.el);
	}
	componentDidLoad() {
		this.checkCollapsibleHeader();
	}
	componentDidUpdate() {
		this.checkCollapsibleHeader();
	}
	disconnectedCallback() {
		this.destroyCollapsibleHeader();
	}
	async checkCollapsibleHeader() {
		if (getIonMode(this) !== "ios") return;
		const { collapse } = this;
		const hasCondense = collapse === "condense";
		const hasFade = collapse === "fade";
		this.destroyCollapsibleHeader();
		if (hasCondense) {
			const pageEl = this.el.closest("ion-app,ion-page,.ion-page,page-inner");
			const contentEl = pageEl ? findIonContent(pageEl) : null;
			writeTask(() => {
				const title = cloneElement("ion-title");
				title.size = "large";
				cloneElement("ion-back-button");
			});
			await this.setupCondenseHeader(contentEl, pageEl);
		} else if (hasFade) {
			const pageEl = this.el.closest("ion-app,ion-page,.ion-page,page-inner");
			const contentEl = pageEl ? findIonContent(pageEl) : null;
			if (!contentEl) {
				printIonContentErrorMsg(this.el);
				return;
			}
			const condenseHeader = contentEl.querySelector("ion-header[collapse=\"condense\"]");
			await this.setupFadeHeader(contentEl, condenseHeader);
		}
	}
	destroyCollapsibleHeader() {
		if (this.intersectionObserver) {
			this.intersectionObserver.disconnect();
			this.intersectionObserver = void 0;
		}
		if (this.scrollEl && this.contentScrollCallback) {
			this.scrollEl.removeEventListener("scroll", this.contentScrollCallback);
			this.contentScrollCallback = void 0;
		}
		if (this.collapsibleMainHeader) {
			this.collapsibleMainHeader.classList.remove("header-collapse-main");
			this.collapsibleMainHeader = void 0;
		}
	}
	async setupCondenseHeader(contentEl, pageEl) {
		if (!contentEl || !pageEl) {
			printIonContentErrorMsg(this.el);
			return;
		}
		if (typeof IntersectionObserver === "undefined") return;
		this.scrollEl = await getScrollElement(contentEl);
		const headers = pageEl.querySelectorAll("ion-header");
		this.collapsibleMainHeader = Array.from(headers).find((header) => header.collapse !== "condense");
		if (!this.collapsibleMainHeader) return;
		const mainHeaderIndex = createHeaderIndex(this.collapsibleMainHeader);
		const scrollHeaderIndex = createHeaderIndex(this.el);
		if (!mainHeaderIndex || !scrollHeaderIndex) return;
		setHeaderActive(mainHeaderIndex, false);
		setToolbarBackgroundOpacity(mainHeaderIndex.el, 0);
		/**
		* Handle interaction between toolbar collapse and
		* showing/hiding content in the primary ion-header
		* as well as progressively showing/hiding the main header
		* border as the top-most toolbar collapses or expands.
		*/
		const toolbarIntersection = (ev) => {
			handleToolbarIntersection(ev, mainHeaderIndex, scrollHeaderIndex, this.scrollEl);
		};
		this.intersectionObserver = new IntersectionObserver(toolbarIntersection, {
			root: contentEl,
			threshold: [
				.25,
				.3,
				.4,
				.5,
				.6,
				.7,
				.8,
				.9,
				1
			]
		});
		this.intersectionObserver.observe(scrollHeaderIndex.toolbars[scrollHeaderIndex.toolbars.length - 1].el);
		/**
		* Handle scaling of large iOS titles and
		* showing/hiding border on last toolbar
		* in primary header
		*/
		this.contentScrollCallback = () => {
			handleContentScroll(this.scrollEl, scrollHeaderIndex, contentEl);
		};
		this.scrollEl.addEventListener("scroll", this.contentScrollCallback);
		writeTask(() => {
			if (this.collapsibleMainHeader !== void 0) this.collapsibleMainHeader.classList.add("header-collapse-main");
		});
	}
	render() {
		const { translucent, inheritedAttributes } = this;
		const mode = getIonMode(this);
		const collapse = this.collapse || "none";
		const isCondensed = collapse === "condense";
		const roleType = getRoleType(hostContext("ion-menu", this.el), isCondensed, mode);
		return h(Host, {
			key: "863c4568cd7b8c0ec55109f193bbbaed68a1346e",
			role: roleType,
			class: {
				[mode]: true,
				[`header-${mode}`]: true,
				[`header-translucent`]: this.translucent,
				[`header-collapse-${collapse}`]: true,
				[`header-translucent-${mode}`]: this.translucent
			},
			...inheritedAttributes
		}, mode === "ios" && translucent && h("div", {
			key: "25c3bdce328b0b35607d154c8b8374679313d881",
			class: "header-background"
		}), h("slot", { key: "b44fab0a9be7920b9650da26117c783e751e1702" }));
	}
	get el() {
		return getElement(this);
	}
};
Header.style = {
	ios: headerIosCss(),
	md: headerMdCss()
};
var routerOutletCss = () => `:host{left:0;right:0;top:0;bottom:0;position:absolute;contain:layout size style;z-index:0}`;
var RouterOutlet = class {
	constructor(hostRef) {
		registerInstance(this, hostRef);
		this.ionNavWillLoad = createEvent(this, "ionNavWillLoad", 7);
		this.ionNavWillChange = createEvent(this, "ionNavWillChange", 3);
		this.ionNavDidChange = createEvent(this, "ionNavDidChange", 3);
		this.lockController = createLockController();
		this.gestureOrAnimationInProgress = false;
		/**
		* The mode determines which platform styles to use.
		*/
		this.mode = getIonMode(this);
		/**
		* If `true`, the router-outlet should animate the transition of components.
		*/
		this.animated = true;
	}
	swipeGestureChanged() {
		this.updateGestureEnabled();
	}
	swipeHandlerChanged() {
		this.updateGestureEnabled();
	}
	async connectedCallback() {
		const onStart = () => {
			this.gestureOrAnimationInProgress = true;
			/**
			* Without animations there's nothing for the swipe to drive, so
			* wait until the gesture ends to decide whether to go back.
			*/
			if (!(this.animated && config.getBoolean("animated", true))) {
				this.unblockSwipeClicks = blockSwipeClicks(this.el);
				return;
			}
			if (this.swipeHandler) this.swipeHandler.onStart();
		};
		this.gesture = (await import("./swipe-back-BZdyM2Q--eWeTb_yz.js")).createSwipeBackGesture(this.el, () => !this.gestureOrAnimationInProgress && !!this.swipeHandler && this.swipeHandler.canStart(), () => onStart(), (step) => this.ani?.progressStep(step), (shouldComplete, step, dur) => {
			if (this.ani) {
				this.ani.onFinish(() => {
					this.gestureOrAnimationInProgress = false;
					if (this.swipeHandler) this.swipeHandler.onEnd(shouldComplete);
				}, { oneTimeCallback: true });
				let newStepValue = shouldComplete ? -.001 : .001;
				/**
				* Animation will be reversed here, so need to
				* reverse the easing curve as well
				*
				* Additionally, we need to account for the time relative
				* to the new easing curve, as `stepValue` is going to be given
				* in terms of a linear curve.
				*/
				if (!shouldComplete) {
					this.ani.easing("cubic-bezier(1, 0, 0.68, 0.28)");
					newStepValue += getTimeGivenProgression([0, 0], [1, 0], [.68, .28], [1, 1], step)[0];
				} else newStepValue += getTimeGivenProgression([0, 0], [.32, .72], [0, 1], [1, 1], step)[0];
				this.ani.progressEnd(shouldComplete ? 1 : 0, newStepValue, dur);
			} else {
				const { swipeHandler, unblockSwipeClicks: unblock } = this;
				this.unblockSwipeClicks = void 0;
				if (unblock && shouldComplete && swipeHandler?.canStart()) new Promise((resolve) => resolve(swipeHandler.onStart())).then(() => swipeHandler.onEnd(true)).finally(() => {
					this.gestureOrAnimationInProgress = false;
					unblock();
				});
				else {
					this.gestureOrAnimationInProgress = false;
					unblock?.();
				}
			}
		});
		if (this.swipeGesture === void 0) this.swipeGesture = config.getBoolean("swipeBackEnabled", this.mode === "ios");
		else this.updateGestureEnabled();
	}
	componentWillLoad() {
		this.ionNavWillLoad.emit();
	}
	updateGestureEnabled() {
		if (this.gesture) this.gesture.enable(this.swipeHandler !== void 0 && this.swipeGesture === true);
	}
	disconnectedCallback() {
		if (this.gesture) {
			this.gesture.destroy();
			this.gesture = void 0;
		}
		if (this.unblockSwipeClicks) {
			this.unblockSwipeClicks();
			this.unblockSwipeClicks = void 0;
			this.gestureOrAnimationInProgress = false;
		}
	}
	/** @internal */
	async commit(enteringEl, leavingEl, opts) {
		const unlock = await this.lockController.lock();
		let changed = false;
		try {
			changed = await this.transition(enteringEl, leavingEl, opts);
		} catch (e) {
			printIonError("[ion-router-outlet] - Exception in commit:", e);
		}
		unlock();
		return changed;
	}
	/** @internal */
	async setRouteId(id, params, direction, animation) {
		return {
			changed: await this.setRoot(id, params, {
				duration: direction === "root" ? 0 : void 0,
				direction: direction === "back" ? "back" : "forward",
				animationBuilder: animation
			}),
			element: this.activeEl
		};
	}
	/** @internal */
	async getRouteId() {
		const active = this.activeEl;
		return active ? {
			id: active.tagName,
			element: active,
			params: this.activeParams
		} : void 0;
	}
	async setRoot(component, params, opts) {
		if (this.activeComponent === component && shallowEqualStringMap(params, this.activeParams)) return false;
		const leavingEl = this.activeEl;
		const enteringEl = await attachComponent(this.delegate, this.el, component, ["ion-page", "ion-page-invisible"], params);
		this.activeComponent = component;
		this.activeEl = enteringEl;
		this.activeParams = params;
		await this.commit(enteringEl, leavingEl, opts);
		await detachComponent(this.delegate, leavingEl);
		return true;
	}
	async transition(enteringEl, leavingEl, opts = {}) {
		if (leavingEl === enteringEl) return false;
		this.ionNavWillChange.emit();
		const { el, mode } = this;
		const animated = this.animated && config.getBoolean("animated", true);
		const animationBuilder = opts.animationBuilder || this.animation || config.get("navAnimation");
		await transition({
			mode,
			animated,
			enteringEl,
			leavingEl,
			baseEl: el,
			/**
			* We need to wait for all Stencil components
			* to be ready only when using the lazy
			* loaded bundle.
			*/
			deepWait: hasLazyBuild(el),
			progressCallback: opts.progressAnimation ? (ani) => {
				/**
				* Because this progress callback is called asynchronously
				* it is possible for the gesture to start and end before
				* the animation is ever set. In that scenario, we should
				* immediately call progressEnd so that the transition promise
				* resolves and the gesture does not get locked up.
				*/
				if (ani !== void 0 && !this.gestureOrAnimationInProgress) {
					this.gestureOrAnimationInProgress = true;
					ani.onFinish(() => {
						this.gestureOrAnimationInProgress = false;
						if (this.swipeHandler) this.swipeHandler.onEnd(false);
					}, { oneTimeCallback: true });
					/**
					* Playing animation to beginning
					* with a duration of 0 prevents
					* any flickering when the animation
					* is later cleaned up.
					*/
					ani.progressEnd(0, 0, 0);
				} else this.ani = ani;
			} : void 0,
			...opts,
			animationBuilder
		});
		this.ionNavDidChange.emit();
		return true;
	}
	render() {
		return h("slot", { key: "078cdc7a63b98570746409fc08c4af80f8d7da4d" });
	}
	get el() {
		return getElement(this);
	}
	static get watchers() {
		return {
			"swipeGesture": [{ "swipeGestureChanged": 0 }],
			"swipeHandler": [{ "swipeHandlerChanged": 0 }]
		};
	}
};
RouterOutlet.style = routerOutletCss();
var titleIosCss = () => `:host{--color:initial;display:-ms-flexbox;display:flex;-ms-flex:1;flex:1;-ms-flex-align:center;align-items:center;-webkit-transform:translateZ(0);transform:translateZ(0);color:var(--color)}:host(.ion-color){color:var(--ion-color-base)}.toolbar-title{display:block;width:100%;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;pointer-events:auto}:host(.title-small) .toolbar-title{white-space:normal}:host{top:0;-webkit-padding-start:90px;padding-inline-start:90px;-webkit-padding-end:90px;padding-inline-end:90px;padding-top:var(--padding-top);padding-bottom:var(--padding-bottom);position:absolute;width:100%;height:100%;-webkit-transform:translateZ(0);transform:translateZ(0);font-size:min(1.0625rem, 20.4px);font-weight:600;text-align:center;-webkit-box-sizing:border-box;box-sizing:border-box;pointer-events:none}:host{inset-inline-start:0}:host(.title-small){-webkit-padding-start:9px;padding-inline-start:9px;-webkit-padding-end:9px;padding-inline-end:9px;padding-top:6px;padding-bottom:16px;position:relative;font-size:min(0.8125rem, 23.4px);font-weight:normal}:host(.title-large){-webkit-padding-start:12px;padding-inline-start:12px;-webkit-padding-end:12px;padding-inline-end:12px;padding-top:2px;padding-bottom:4px;-webkit-transform-origin:left center;transform-origin:left center;position:static;-ms-flex-align:end;align-items:flex-end;min-width:100%;font-size:min(2.125rem, 61.2px);font-weight:700;text-align:start}:host(.title-large.title-rtl){-webkit-transform-origin:right center;transform-origin:right center}:host(.title-large.ion-cloned-element){--color:var(--ion-text-color, #000);font-family:var(--ion-font-family)}:host(.title-large) .toolbar-title{-webkit-transform-origin:inherit;transform-origin:inherit;width:auto}:host-context([dir=rtl]):host(.title-large) .toolbar-title,:host-context([dir=rtl]).title-large .toolbar-title{-webkit-transform-origin:calc(100% - inherit);transform-origin:calc(100% - inherit)}@supports selector(:dir(rtl)){:host(.title-large:dir(rtl)) .toolbar-title{-webkit-transform-origin:calc(100% - inherit);transform-origin:calc(100% - inherit)}}`;
var titleMdCss = () => `:host{--color:initial;display:-ms-flexbox;display:flex;-ms-flex:1;flex:1;-ms-flex-align:center;align-items:center;-webkit-transform:translateZ(0);transform:translateZ(0);color:var(--color)}:host(.ion-color){color:var(--ion-color-base)}.toolbar-title{display:block;width:100%;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;pointer-events:auto}:host(.title-small) .toolbar-title{white-space:normal}:host{-webkit-padding-start:20px;padding-inline-start:20px;-webkit-padding-end:20px;padding-inline-end:20px;padding-top:0;padding-bottom:0;font-size:1.25rem;font-weight:500;letter-spacing:0.0125em}:host(.title-small){width:100%;height:100%;font-size:0.9375rem;font-weight:normal}`;
var ToolbarTitle = class {
	constructor(hostRef) {
		registerInstance(this, hostRef);
		this.ionStyle = createEvent(this, "ionStyle", 7);
	}
	sizeChanged() {
		this.emitStyle();
	}
	connectedCallback() {
		this.emitStyle();
	}
	emitStyle() {
		const size = this.getSize();
		this.ionStyle.emit({ [`title-${size}`]: true });
	}
	getSize() {
		return this.size !== void 0 ? this.size : "default";
	}
	render() {
		const mode = getIonMode(this);
		const size = this.getSize();
		return h(Host, {
			key: "8d17feb9f9dcb9eb8e3b8ae6e831bdedb890771c",
			class: createColorClasses(this.color, {
				[mode]: true,
				[`title-${size}`]: true,
				"title-rtl": isRTL(this.el)
			})
		}, h("div", {
			key: "0346aae3fca1e3ae443b1b511c44ab1f803cb103",
			class: "toolbar-title"
		}, h("slot", { key: "e1945845df471d5eb8c3cdeb568c478abf5ad70e" })));
	}
	get el() {
		return getElement(this);
	}
	static get watchers() {
		return { "size": [{ "sizeChanged": 0 }] };
	}
};
ToolbarTitle.style = {
	ios: titleIosCss(),
	md: titleMdCss()
};
var toolbarIosCss = () => `:host{--border-width:0;--border-style:solid;--opacity:1;--opacity-scale:1;-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;display:block;position:relative;width:100%;padding-right:var(--ion-safe-area-right);padding-left:var(--ion-safe-area-left);color:var(--color);font-family:var(--ion-font-family, inherit);contain:content;z-index:10;-webkit-box-sizing:border-box;box-sizing:border-box}:host(.ion-color){color:var(--ion-color-contrast)}:host(.ion-color) .toolbar-background{background:var(--ion-color-base)}.toolbar-container{-webkit-padding-start:var(--padding-start);padding-inline-start:var(--padding-start);-webkit-padding-end:var(--padding-end);padding-inline-end:var(--padding-end);padding-top:var(--padding-top);padding-bottom:var(--padding-bottom);display:-ms-flexbox;display:flex;position:relative;-ms-flex-direction:row;flex-direction:row;-ms-flex-align:center;align-items:center;-ms-flex-pack:justify;justify-content:space-between;width:100%;min-height:var(--min-height);contain:content;overflow:hidden;z-index:10;-webkit-box-sizing:border-box;box-sizing:border-box}.toolbar-background{left:0;right:0;top:0;bottom:0;position:absolute;-webkit-transform:translateZ(0);transform:translateZ(0);border-width:var(--border-width);border-style:var(--border-style);border-color:var(--border-color);background:var(--background);contain:strict;opacity:calc(var(--opacity) * var(--opacity-scale));z-index:-1;pointer-events:none}::slotted(ion-progress-bar){left:0;right:0;bottom:0;position:absolute}:host{--background:var(--ion-toolbar-background, var(--ion-color-step-50, var(--ion-background-color-step-50, #f7f7f7)));--color:var(--ion-toolbar-color, var(--ion-text-color, #000));--border-color:var(--ion-toolbar-border-color, var(--ion-border-color, var(--ion-color-step-150, var(--ion-background-color-step-150, rgba(0, 0, 0, 0.2)))));--padding-top:3px;--padding-bottom:3px;--padding-start:4px;--padding-end:4px;--min-height:44px}.toolbar-content{-ms-flex:1;flex:1;-ms-flex-order:4;order:4;min-width:0}:host(.toolbar-segment) .toolbar-content{display:-ms-inline-flexbox;display:inline-flex}:host(.toolbar-searchbar) .toolbar-container{padding-top:0;padding-bottom:0}:host(.toolbar-searchbar) ::slotted(*){-ms-flex-item-align:start;align-self:start}:host(.toolbar-searchbar) ::slotted(ion-chip){margin-top:3px}::slotted(ion-buttons){min-height:38px}::slotted([slot=start]){-ms-flex-order:2;order:2}::slotted([slot=secondary]){-ms-flex-order:3;order:3}::slotted([slot=primary]){-ms-flex-order:5;order:5;text-align:end}::slotted([slot=end]){-ms-flex-order:6;order:6;text-align:end}:host(.toolbar-title-large) .toolbar-container{-ms-flex-wrap:wrap;flex-wrap:wrap;-ms-flex-align:start;align-items:flex-start}:host(.toolbar-title-large) .toolbar-content ion-title{-ms-flex:1;flex:1;-ms-flex-order:8;order:8;min-width:100%}`;
var toolbarMdCss = () => `:host{--border-width:0;--border-style:solid;--opacity:1;--opacity-scale:1;-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;display:block;position:relative;width:100%;padding-right:var(--ion-safe-area-right);padding-left:var(--ion-safe-area-left);color:var(--color);font-family:var(--ion-font-family, inherit);contain:content;z-index:10;-webkit-box-sizing:border-box;box-sizing:border-box}:host(.ion-color){color:var(--ion-color-contrast)}:host(.ion-color) .toolbar-background{background:var(--ion-color-base)}.toolbar-container{-webkit-padding-start:var(--padding-start);padding-inline-start:var(--padding-start);-webkit-padding-end:var(--padding-end);padding-inline-end:var(--padding-end);padding-top:var(--padding-top);padding-bottom:var(--padding-bottom);display:-ms-flexbox;display:flex;position:relative;-ms-flex-direction:row;flex-direction:row;-ms-flex-align:center;align-items:center;-ms-flex-pack:justify;justify-content:space-between;width:100%;min-height:var(--min-height);contain:content;overflow:hidden;z-index:10;-webkit-box-sizing:border-box;box-sizing:border-box}.toolbar-background{left:0;right:0;top:0;bottom:0;position:absolute;-webkit-transform:translateZ(0);transform:translateZ(0);border-width:var(--border-width);border-style:var(--border-style);border-color:var(--border-color);background:var(--background);contain:strict;opacity:calc(var(--opacity) * var(--opacity-scale));z-index:-1;pointer-events:none}::slotted(ion-progress-bar){left:0;right:0;bottom:0;position:absolute}:host{--background:var(--ion-toolbar-background, var(--ion-background-color, #fff));--color:var(--ion-toolbar-color, var(--ion-text-color, #424242));--border-color:var(--ion-toolbar-border-color, var(--ion-border-color, var(--ion-color-step-150, var(--ion-background-color-step-150, #c1c4cd))));--padding-top:0;--padding-bottom:0;--padding-start:0;--padding-end:0;--min-height:56px}.toolbar-content{-ms-flex:1;flex:1;-ms-flex-order:3;order:3;min-width:0;max-width:100%}::slotted(.buttons-first-slot){-webkit-margin-start:4px;margin-inline-start:4px}::slotted(.buttons-last-slot){-webkit-margin-end:4px;margin-inline-end:4px}::slotted([slot=start]){-ms-flex-order:2;order:2}::slotted([slot=secondary]){-ms-flex-order:4;order:4}::slotted([slot=primary]){-ms-flex-order:5;order:5;text-align:end}::slotted([slot=end]){-ms-flex-order:6;order:6;text-align:end}`;
var Toolbar = class {
	constructor(hostRef) {
		registerInstance(this, hostRef);
		this.childrenStyles = /* @__PURE__ */ new Map();
	}
	componentWillLoad() {
		const buttons = Array.from(this.el.querySelectorAll("ion-buttons"));
		const firstButtons = buttons.find((button) => {
			return button.slot === "start";
		});
		if (firstButtons) firstButtons.classList.add("buttons-first-slot");
		const buttonsReversed = buttons.reverse();
		const lastButtons = buttonsReversed.find((button) => button.slot === "end") || buttonsReversed.find((button) => button.slot === "primary") || buttonsReversed.find((button) => button.slot === "secondary");
		if (lastButtons) lastButtons.classList.add("buttons-last-slot");
	}
	childrenStyle(ev) {
		ev.stopPropagation();
		const tagName = ev.target.tagName;
		const updatedStyles = ev.detail;
		const newStyles = {};
		const childStyles = this.childrenStyles.get(tagName) || {};
		let hasStyleChange = false;
		Object.keys(updatedStyles).forEach((key) => {
			const childKey = `toolbar-${key}`;
			const newValue = updatedStyles[key];
			if (newValue !== childStyles[childKey]) hasStyleChange = true;
			if (newValue) newStyles[childKey] = true;
		});
		if (hasStyleChange) {
			this.childrenStyles.set(tagName, newStyles);
			forceUpdate(this);
		}
	}
	render() {
		const mode = getIonMode(this);
		const childStyles = {};
		this.childrenStyles.forEach((value) => {
			Object.assign(childStyles, value);
		});
		return h(Host, {
			key: "c16803dc4eae9972ef19bf43aa74b94feb4fd4c1",
			class: {
				...childStyles,
				...createColorClasses(this.color, {
					[mode]: true,
					"in-toolbar": hostContext("ion-toolbar", this.el)
				})
			}
		}, h("div", {
			key: "20e3f85844c94b8399c245d2df125e6ab678d681",
			class: "toolbar-background",
			part: "background"
		}), h("div", {
			key: "12f09e324e8d9130b9d30c493106b500233fb016",
			class: "toolbar-container",
			part: "container"
		}, h("slot", {
			key: "6da0fe99ee0c4d7c969712e2908a4e7e6be5ed2c",
			name: "start"
		}), h("slot", {
			key: "177c346d6dcabb7857d810cda7d25c6dde32e6e2",
			name: "secondary"
		}), h("div", {
			key: "8c921b415940c71bf4c1a2c5c6887f36ad1afd16",
			class: "toolbar-content",
			part: "content"
		}, h("slot", { key: "1f2976b80d967bd51e86ed1357b363271d655df2" })), h("slot", {
			key: "0f7618044a7e8b0d9b715a8e208070f7ef2ee4c8",
			name: "primary"
		}), h("slot", {
			key: "125c393197e0660a3c2638dd4628c41ef7e05f19",
			name: "end"
		})));
	}
	get el() {
		return getElement(this);
	}
};
Toolbar.style = {
	ios: toolbarIosCss(),
	md: toolbarMdCss()
};
//#endregion
export { App as ion_app, Buttons as ion_buttons, Content as ion_content, Footer as ion_footer, Header as ion_header, RouterOutlet as ion_router_outlet, ToolbarTitle as ion_title, Toolbar as ion_toolbar };
