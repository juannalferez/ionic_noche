//#region node_modules/@ionic/core/dist/esm/lock-controller-B-hirT0v.js
/*!
* (C) Ionic http://ionicframework.com - MIT License
*/
/**
* Creates a lock controller.
*
* Claiming a lock means that nothing else can acquire the lock until it is released.
* This can momentarily prevent execution of code that needs to wait for the earlier code to finish.
* For example, this can be used to prevent multiple transitions from occurring at the same time.
*/
var createLockController = () => {
	let waitPromise;
	/**
	* When lock() is called, the lock is claimed.
	* Once a lock has been claimed, it cannot be claimed again until it is released.
	* When this function gets resolved, the lock is released, allowing it to be claimed again.
	*
	* @example ```tsx
	* const unlock = await this.lockController.lock();
	* // do other stuff
	* unlock();
	* ```
	*/
	const lock = async () => {
		const p = waitPromise;
		let resolve;
		waitPromise = new Promise((r) => resolve = r);
		if (p !== void 0) await p;
		return resolve;
	};
	return { lock };
};
//#endregion
export { createLockController as t };
