import { a as config, c as createEvent, d as getElement, p as h, r as Host, v as registerInstance } from "./index-BpRUsN_W-Dyk8UFjA.js";
import { y as raf } from "./helpers-p94IkmEA-5uAy2AkJ.js";
import { t as createAnimation } from "./animation-C_V9lXzL-Cr0C6JA2.js";
import "./gesture-controller-B_gJaBk0-B8pQAih_.js";
import { t as getIonMode } from "./ionic-global-Cep6oYzK-DYtGOxOW.js";
import { i as sanitizeDOMString } from "./index-CK8uF0iB-BeQDeIha.js";
import { n as getClassMap } from "./theme-byZM6qHV-CVcL0HyM.js";
import "./framework-delegate-CW5_kWfc-BdHig9H3.js";
import { C as restoreRootFocusTrapAccessibility, S as present, T as setOverlayId, c as createDelegateController, d as eventMethod, l as createTriggerController, s as cleanupRootFocusTrapAccessibility, t as BACKDROP, u as dismiss, x as prepareOverlay } from "./overlays-BBgMM61s-DkyFJ5KT.js";
import { t as createLockController } from "./lock-controller-B-hirT0v-wdq_Ov9y.js";
//#region node_modules/@ionic/core/dist/esm/ion-loading.entry.js
/*!
* (C) Ionic http://ionicframework.com - MIT License
*/
/**
* iOS Loading Enter Animation
*/
var iosEnterAnimation = (baseEl) => {
	const baseAnimation = createAnimation();
	const backdropAnimation = createAnimation();
	const wrapperAnimation = createAnimation();
	backdropAnimation.addElement(baseEl.querySelector("ion-backdrop")).fromTo("opacity", .01, "var(--backdrop-opacity)").beforeStyles({ "pointer-events": "none" }).afterClearStyles(["pointer-events"]);
	wrapperAnimation.addElement(baseEl.querySelector(".loading-wrapper")).keyframes([{
		offset: 0,
		opacity: .01,
		transform: "scale(1.1)"
	}, {
		offset: 1,
		opacity: 1,
		transform: "scale(1)"
	}]);
	return baseAnimation.addElement(baseEl).easing("ease-in-out").duration(200).addAnimation([backdropAnimation, wrapperAnimation]);
};
/**
* iOS Loading Leave Animation
*/
var iosLeaveAnimation = (baseEl) => {
	const baseAnimation = createAnimation();
	const backdropAnimation = createAnimation();
	const wrapperAnimation = createAnimation();
	backdropAnimation.addElement(baseEl.querySelector("ion-backdrop")).fromTo("opacity", "var(--backdrop-opacity)", 0);
	wrapperAnimation.addElement(baseEl.querySelector(".loading-wrapper")).keyframes([{
		offset: 0,
		opacity: .99,
		transform: "scale(1)"
	}, {
		offset: 1,
		opacity: 0,
		transform: "scale(0.9)"
	}]);
	return baseAnimation.addElement(baseEl).easing("ease-in-out").duration(200).addAnimation([backdropAnimation, wrapperAnimation]);
};
/**
* Md Loading Enter Animation
*/
var mdEnterAnimation = (baseEl) => {
	const baseAnimation = createAnimation();
	const backdropAnimation = createAnimation();
	const wrapperAnimation = createAnimation();
	backdropAnimation.addElement(baseEl.querySelector("ion-backdrop")).fromTo("opacity", .01, "var(--backdrop-opacity)").beforeStyles({ "pointer-events": "none" }).afterClearStyles(["pointer-events"]);
	wrapperAnimation.addElement(baseEl.querySelector(".loading-wrapper")).keyframes([{
		offset: 0,
		opacity: .01,
		transform: "scale(1.1)"
	}, {
		offset: 1,
		opacity: 1,
		transform: "scale(1)"
	}]);
	return baseAnimation.addElement(baseEl).easing("ease-in-out").duration(200).addAnimation([backdropAnimation, wrapperAnimation]);
};
/**
* Md Loading Leave Animation
*/
var mdLeaveAnimation = (baseEl) => {
	const baseAnimation = createAnimation();
	const backdropAnimation = createAnimation();
	const wrapperAnimation = createAnimation();
	backdropAnimation.addElement(baseEl.querySelector("ion-backdrop")).fromTo("opacity", "var(--backdrop-opacity)", 0);
	wrapperAnimation.addElement(baseEl.querySelector(".loading-wrapper")).keyframes([{
		offset: 0,
		opacity: .99,
		transform: "scale(1)"
	}, {
		offset: 1,
		opacity: 0,
		transform: "scale(0.9)"
	}]);
	return baseAnimation.addElement(baseEl).easing("ease-in-out").duration(200).addAnimation([backdropAnimation, wrapperAnimation]);
};
var loadingIosCss = () => `.sc-ion-loading-ios-h{--min-width:auto;--width:auto;--min-height:auto;--height:auto;-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;left:0;right:0;top:0;bottom:0;display:-ms-flexbox;display:flex;position:fixed;-ms-flex-align:center;align-items:center;-ms-flex-pack:center;justify-content:center;outline:none;font-family:var(--ion-font-family, inherit);contain:strict;-ms-touch-action:none;touch-action:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;z-index:1001}.overlay-hidden.sc-ion-loading-ios-h{display:none}.loading-wrapper.sc-ion-loading-ios{display:-ms-flexbox;display:flex;-ms-flex-align:inherit;align-items:inherit;-ms-flex-pack:inherit;justify-content:inherit;width:var(--width);min-width:var(--min-width);max-width:var(--max-width);height:var(--height);min-height:var(--min-height);max-height:var(--max-height);background:var(--background);opacity:0;z-index:10}ion-spinner.sc-ion-loading-ios{color:var(--spinner-color)}.sc-ion-loading-ios-h{--background:var(--ion-overlay-background-color, var(--ion-color-step-100, var(--ion-background-color-step-100, #f9f9f9)));--max-width:270px;--max-height:90%;--spinner-color:var(--ion-color-step-600, var(--ion-text-color-step-400, #666666));--backdrop-opacity:var(--ion-backdrop-opacity, 0.3);color:var(--ion-text-color, #000);font-size:0.875rem}.loading-wrapper.sc-ion-loading-ios{border-radius:8px;-webkit-padding-start:34px;padding-inline-start:34px;-webkit-padding-end:34px;padding-inline-end:34px;padding-top:24px;padding-bottom:24px}@supports ((-webkit-backdrop-filter: blur(0)) or (backdrop-filter: blur(0))){.loading-translucent.sc-ion-loading-ios-h .loading-wrapper.sc-ion-loading-ios{background-color:rgba(var(--ion-background-color-rgb, 255, 255, 255), 0.8);-webkit-backdrop-filter:saturate(180%) blur(20px);backdrop-filter:saturate(180%) blur(20px)}}.loading-content.sc-ion-loading-ios{font-weight:bold}.loading-spinner.sc-ion-loading-ios+.loading-content.sc-ion-loading-ios{-webkit-margin-start:16px;margin-inline-start:16px}`;
var loadingMdCss = () => `.sc-ion-loading-md-h{--min-width:auto;--width:auto;--min-height:auto;--height:auto;-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;left:0;right:0;top:0;bottom:0;display:-ms-flexbox;display:flex;position:fixed;-ms-flex-align:center;align-items:center;-ms-flex-pack:center;justify-content:center;outline:none;font-family:var(--ion-font-family, inherit);contain:strict;-ms-touch-action:none;touch-action:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;z-index:1001}.overlay-hidden.sc-ion-loading-md-h{display:none}.loading-wrapper.sc-ion-loading-md{display:-ms-flexbox;display:flex;-ms-flex-align:inherit;align-items:inherit;-ms-flex-pack:inherit;justify-content:inherit;width:var(--width);min-width:var(--min-width);max-width:var(--max-width);height:var(--height);min-height:var(--min-height);max-height:var(--max-height);background:var(--background);opacity:0;z-index:10}ion-spinner.sc-ion-loading-md{color:var(--spinner-color)}.sc-ion-loading-md-h{--background:var(--ion-color-step-50, var(--ion-background-color-step-50, #f2f2f2));--max-width:280px;--max-height:90%;--spinner-color:var(--ion-color-primary, #0054e9);--backdrop-opacity:var(--ion-backdrop-opacity, 0.32);color:var(--ion-color-step-850, var(--ion-text-color-step-150, #262626));font-size:0.875rem}.loading-wrapper.sc-ion-loading-md{border-radius:2px;-webkit-padding-start:24px;padding-inline-start:24px;-webkit-padding-end:24px;padding-inline-end:24px;padding-top:24px;padding-bottom:24px;-webkit-box-shadow:0 16px 20px rgba(0, 0, 0, 0.4);box-shadow:0 16px 20px rgba(0, 0, 0, 0.4)}.loading-spinner.sc-ion-loading-md+.loading-content.sc-ion-loading-md{-webkit-margin-start:16px;margin-inline-start:16px}`;
var Loading = class {
	constructor(hostRef) {
		registerInstance(this, hostRef);
		this.didPresent = createEvent(this, "ionLoadingDidPresent", 7);
		this.willPresent = createEvent(this, "ionLoadingWillPresent", 7);
		this.willDismiss = createEvent(this, "ionLoadingWillDismiss", 7);
		this.didDismiss = createEvent(this, "ionLoadingDidDismiss", 7);
		this.didPresentShorthand = createEvent(this, "didPresent", 7);
		this.willPresentShorthand = createEvent(this, "willPresent", 7);
		this.willDismissShorthand = createEvent(this, "willDismiss", 7);
		this.didDismissShorthand = createEvent(this, "didDismiss", 7);
		this.delegateController = createDelegateController(this);
		this.lockController = createLockController();
		this.triggerController = createTriggerController();
		this.customHTMLEnabled = config.get("innerHTMLTemplatesEnabled", false);
		this.presented = false;
		/** @internal */
		this.hasController = false;
		/**
		* If `true`, the keyboard will be automatically dismissed when the overlay is presented.
		*/
		this.keyboardClose = true;
		/**
		* Number of milliseconds to wait before dismissing the loading indicator.
		*/
		this.duration = 0;
		/**
		* If `true`, the loading indicator will be dismissed when the backdrop is clicked.
		*/
		this.backdropDismiss = false;
		/**
		* If `true`, a backdrop will be displayed behind the loading indicator.
		*/
		this.showBackdrop = true;
		/**
		* If `true`, the loading indicator will be translucent.
		* Only applies when the mode is `"ios"` and the device supports
		* [`backdrop-filter`](https://developer.mozilla.org/en-US/docs/Web/CSS/backdrop-filter#Browser_compatibility).
		*/
		this.translucent = false;
		/**
		* If `true`, the loading indicator will animate.
		*/
		this.animated = true;
		/**
		* If `true`, the loading indicator will open. If `false`, the loading indicator will close.
		* Use this if you need finer grained control over presentation, otherwise
		* just use the loadingController or the `trigger` property.
		* Note: `isOpen` will not automatically be set back to `false` when
		* the loading indicator dismisses. You will need to do that in your code.
		*/
		this.isOpen = false;
		this.onBackdropTap = () => {
			this.dismiss(void 0, BACKDROP);
		};
	}
	onIsOpenChange(newValue, oldValue) {
		if (newValue === true && oldValue === false) this.present();
		else if (newValue === false && oldValue === true) this.dismiss();
	}
	triggerChanged() {
		const { trigger, el, triggerController } = this;
		if (trigger) triggerController.addClickListener(el, trigger);
	}
	connectedCallback() {
		prepareOverlay(this.el);
		this.triggerChanged();
		if (this.presented) restoreRootFocusTrapAccessibility(this.el);
	}
	componentWillLoad() {
		if (this.spinner === void 0) {
			const mode = getIonMode(this);
			this.spinner = config.get("loadingSpinner", config.get("spinner", mode === "ios" ? "lines" : "crescent"));
		}
		if (!this.htmlAttributes?.id) setOverlayId(this.el);
	}
	componentDidLoad() {
		/**
		* If loading indicator was rendered with isOpen="true"
		* then we should open loading indicator immediately.
		*/
		if (this.isOpen === true) raf(() => this.present());
		/**
		* When binding values in frameworks such as Angular
		* it is possible for the value to be set after the Web Component
		* initializes but before the value watcher is set up in Stencil.
		* As a result, the watcher callback may not be fired.
		* We work around this by manually calling the watcher
		* callback when the component has loaded and the watcher
		* is configured.
		*/
		this.triggerChanged();
	}
	disconnectedCallback() {
		this.triggerController.removeClickListener();
		if (this.presented) cleanupRootFocusTrapAccessibility();
	}
	/**
	* Present the loading overlay after it has been created.
	*/
	async present() {
		const unlock = await this.lockController.lock();
		await this.delegateController.attachViewToDom();
		await present(this, "loadingEnter", iosEnterAnimation, mdEnterAnimation);
		if (this.duration > 0) this.durationTimeout = setTimeout(() => this.dismiss(), this.duration + 10);
		unlock();
	}
	/**
	* Dismiss the loading overlay after it has been presented.
	* This is a no-op if the overlay has not been presented yet. If you want
	* to remove an overlay from the DOM that was never presented, use the
	* [remove](https://developer.mozilla.org/en-US/docs/Web/API/Element/remove) method.
	*
	* @param data Any data to emit in the dismiss events.
	* @param role The role of the element that is dismissing the loading.
	* This can be useful in a button handler for determining which button was
	* clicked to dismiss the loading. Some examples include:
	* `"cancel"`, `"destructive"`, `"selected"`, and `"backdrop"`.
	*/
	async dismiss(data, role) {
		const unlock = await this.lockController.lock();
		if (this.durationTimeout) clearTimeout(this.durationTimeout);
		const dismissed = await dismiss(this, data, role, "loadingLeave", iosLeaveAnimation, mdLeaveAnimation);
		if (dismissed) this.delegateController.removeViewFromDom();
		unlock();
		return dismissed;
	}
	/**
	* Returns a promise that resolves when the loading did dismiss.
	*/
	onDidDismiss() {
		return eventMethod(this.el, "ionLoadingDidDismiss");
	}
	/**
	* Returns a promise that resolves when the loading will dismiss.
	*/
	onWillDismiss() {
		return eventMethod(this.el, "ionLoadingWillDismiss");
	}
	renderLoadingMessage(msgId) {
		const { customHTMLEnabled, message } = this;
		if (customHTMLEnabled) return h("div", {
			class: "loading-content",
			id: msgId,
			innerHTML: sanitizeDOMString(message)
		});
		return h("div", {
			class: "loading-content",
			id: msgId
		}, message);
	}
	render() {
		const { message, spinner, htmlAttributes, overlayIndex } = this;
		const mode = getIonMode(this);
		const msgId = `loading-${overlayIndex}-msg`;
		return h(Host, {
			key: "b4430bc66aedeca19d5645667cba73c169c4bd76",
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": message !== void 0 ? msgId : null,
			tabindex: "-1",
			...htmlAttributes,
			style: { zIndex: `${4e4 + this.overlayIndex}` },
			onIonBackdropTap: this.onBackdropTap,
			class: {
				...getClassMap(this.cssClass),
				[mode]: true,
				"overlay-hidden": true,
				"loading-translucent": this.translucent
			}
		}, h("ion-backdrop", {
			key: "dec0df942ae778c99ebd4dbf08d6c2a0a992639d",
			visible: this.showBackdrop,
			tappable: this.backdropDismiss
		}), h("div", {
			key: "71b2d5fc259666225047fc901648ada1efcd5d4b",
			tabindex: "0",
			"aria-hidden": "true"
		}), h("div", {
			key: "1d83dc3b57ee70c9e8c0f006c6fa576bd96ecded",
			class: "loading-wrapper ion-overlay-wrapper"
		}, spinner && h("div", {
			key: "d1cd127e044b8831e396b53122322c1db7e89904",
			class: "loading-spinner"
		}, h("ion-spinner", {
			key: "38c2580cf5659da612872f01801a5fbdc2c023ba",
			name: spinner,
			"aria-hidden": "true"
		})), message !== void 0 && this.renderLoadingMessage(msgId)), h("div", {
			key: "90e5e32ffe0df2c691f364149f43374e676bfaa3",
			tabindex: "0",
			"aria-hidden": "true"
		}));
	}
	get el() {
		return getElement(this);
	}
	static get watchers() {
		return {
			"isOpen": [{ "onIsOpenChange": 0 }],
			"trigger": [{ "triggerChanged": 0 }]
		};
	}
};
Loading.style = {
	ios: loadingIosCss(),
	md: loadingMdCss()
};
//#endregion
export { Loading as ion_loading };
